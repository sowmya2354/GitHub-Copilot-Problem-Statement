const bal = document.querySelector("#balance")
const inc_amt = document.querySelector("#inc-amt")
const exp_amt = document.querySelector("#exp-amt")
const trans = document.querySelector("#trans")
const form = document.querySelector("#form")
const description = document.querySelector('input[name="description"]');
const amount = document.querySelector("#amount");
const dummyData = [
  { id: 1, description: "Flower", amount: -20 },
  { id: 2, description: "Salary", amount: 35000 },
  { id: 3, description: "Book", amount: 10 },
  { id: 4, description: "Camera", amount: -150 },
  { id: 5, description: "Petrol", amount: -250 },
];

let transaction1 = dummyData;

const LocalStorageTrans = JSON.parse(localStorage.getItem("trans"))
let transactions = localStorage.getItem("trans") !== null ? LocalStorageTrans : []
function loadTransactionDetails(transaction) {
  const sign = transaction.amount < 0 ? "-" : "+"
  const item = document.createElement("li")
  item.classList.add(transaction.amount < 0 ? "exp" : "inc")
  item.innerHTML = `${transaction.description}
                    <span>${sign}  ${Math.abs(transaction.amount)}</span>
                     <button class="btn-del" onclick="removeTrans(${transaction.id})">x</button>
                      <button class="btn-edit" onclick="editTrans(${transaction.id})">x</button>
                     `
  trans.appendChild(item)

  console.log(transaction)
}
function removeTrans(id) {
  if (confirm("Are you sure want to delete transaction")) {
    transactions = transactions.filter((transaction) => transaction.id != id)

    config()
    updateLocalStorage()
  }
  else {
    return;
  }
}
function updateAmount() {
  const amounts = transactions.map((transaction) => transaction.amount);
  const total = amounts.reduce((acc, item) => (acc += item), 0).toFixed(2);
  balance.innerHTML = `₹ ${total}`;

  const income = amounts
    .filter((item) => item > 0)
    .reduce((acc, item) => (acc += item), 0)
    .toFixed(2);
  inc_amt.innerHTML = `₹ ${income}`;

  const expenses = amounts
    .filter((item) => item < 0)
    .reduce((acc, item) => (acc += item), 0)
    .toFixed(2);
  exp_amt.innerHTML = `₹ ${Math.abs(expenses)}`;
}
function config() {
  trans.innerHTML = "";
  transactions.forEach(loadTransactionDetails);
  updateAmount();
}
function addTransaction(e) {
  e.preventDefault();
  if (description.value.trim() == "" || amount.value.trim() == "") {
    alert("Please Enter Description and amount");
  } else {
    const transaction = {
      id: UniqueId(),
      description: description.value,
      amount: +amount.value
    }
    transactions.push(transaction)
    loadTransactionDetails(transaction);
    description.value = "";
    amount.value = "";
    updateAmount();
    updateLocalStorage();
  }
}
function editTrans(id) {
  const transaction = transactions.find((t) => t.id === id);

  // Create a form to update the transaction details
  const editForm = document.createElement("form");
  const descriptionInput = document.createElement("input");
  descriptionInput.type = "text";
  descriptionInput.value = transaction.description;
  const amountInput = document.createElement("input");
  amountInput.type = "number";
  amountInput.value = transaction.amount;
  const updateButton = document.createElement("button");
  updateButton.textContent = "Update";
  updateButton.addEventListener("click", function(e) {
    e.preventDefault();
    transaction.description = descriptionInput.value;
    transaction.amount = parseFloat(amountInput.value);
    config();
    updateLocalStorage();
  });

  editForm.appendChild(descriptionInput);
  editForm.appendChild(amountInput);
  editForm.appendChild(updateButton);

  // Replace the transaction item with the edit form
  const transactionItems = document.querySelectorAll("#trans li");
  transactionItems.forEach((item) => {
    if (item.dataset.id === id.toString()) {
      item.replaceWith(editForm);
    }
  });
}
function removeTrans(id) {
  if (confirm("Are you sure you want to delete the transaction?")) {
    transactions = transactions.filter((transaction) => transaction.id !== id);
    config();
    updateLocalStorage();
  } else {
    return;
  }
}





function UniqueId() {
  return Math.floor(Math.random() * 1000000)
}
form.addEventListener("submit", addTransaction);

window.addEventListener("load", function() {
  config();
});
window.addEventListener("load", function() {
  const localData = localStorage.getItem("transactions");
  if (localData) {
    transactions = JSON.parse(localData);
    config();
  } else {
    bal.innerHTML = "₹ 0.00";
    inc_amt.innerHTML = "₹ 0.00";
    exp_amt.innerHTML = "₹ 0.00";
  }
});

function updateLocalStorage() {
  localStorage.setItem("trans", JSON.stringify(transactions));
}